<?php
include 'db_connect.php';
include 'login.php';
$user_id = $_SESSION['user_id'];
// Query to select data from scans table
$sql = "SELECT cve_number, link ,Description ,severity ,solution FROM scans Where user_id=$user_id ORDER BY CASE severity
    WHEN 'Critical' THEN 1
    WHEN 'High' THEN 2
    WHEN 'Medium' THEN 3
    WHEN 'Low' THEN 4
    ELSE 5  -- Handle any other severities if needed
END;";
$result = $conn->query($sql);
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Script Output</title>
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }
    .container {
        width: 80%;
        margin: 50px auto;
        padding: 20px;
        background-color: #fff;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        border-radius: 8px;
    }
    h1 {
        text-align: center;
        color: #333;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    th, td {
        padding: 10px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    th {
        background-color: #f2f2f2;
    }
    a {
        color: #3498db;
        text-decoration: none;
    }
    a:hover {
        text-decoration: underline;
    }
</style>
</head>
<body>
    <div class="container">
        <h1>Script Output</h1>
        <table>
            <thead>
                <tr>
                    <th>CVE</th>
                    <th>Reference Link</th>
                    <th>Description</th>
                    <th>severity</th>
                    <th>solution</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if ($result->num_rows > 0) {
                    // Output data of each row
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . htmlspecialchars($row["cve_number"]) . "</td>";
                        echo "<td><a href='" . htmlspecialchars($row["link"]) . "' target='_blank'>Reference Link</a></td>";
                        echo "<td>" . htmlspecialchars($row["Description"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["severity"]) . "</td>";
                        echo "<td>" . htmlspecialchars($row["solution"]) . "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='2'>No records found</td></tr>";
                }
                $conn->close();
                ?>
            </tbody>
        </table>
    </div>
</body>
</html>
