url="$1"
./nikto.pl -h $url >> allreport.txt
