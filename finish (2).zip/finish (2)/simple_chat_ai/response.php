<?php

require __DIR__ . '/vendor/autoload.php';
use GuzzleHttp\Client;
use GuzzleHttp\Exception\RequestException;

// Your OpenAI API key
$apiKey = '';

// Define the file path for the report and the list of CVEs
$reportFilePath = 'test2.txt';
$downloadDir = 'patches';

// Check if the report file exists
if (!file_exists($reportFilePath)) {
    die("The file $reportFilePath does not exist.");
}

// Read the report content
$reportContent = file_get_contents($reportFilePath);
if (empty($reportContent)) {
    die("The file $reportFilePath is empty.");
}

// Define the prompt text
$text = "this is a report form scaning tool vulnerabilities of a web site , not explain any thing and dont write any thing but,if you find a word called (CVE) in this report,write this word in a table with the number which come after this word untill the last number and  just search about patches for these CVEs from (cve.Mitre.org link) and give me links for patches and write these patches in anthor column and if not find (CVE) just write (this report dont exist CVEs)
 ,dont give me any explain and recommandations , i need just links about patches of CVEs or dont return any thing please:\n\n$reportContent";

// Initialize Guzzle client for OpenAI API
$client = new Client([
    'base_uri' => 'https://api.openai.com',
    'headers' => [
        'Authorization' => 'Bearer ' . $apiKey,
        'Content-Type' => 'application/json',
    ],
    'verify' => __DIR__ . '/cacert.pem', // Update this path to where you saved cacert.pem
]);

try {
    $response = $client->post('/v1/chat/completions', [
        'json' => [
            'model' => 'gpt-3.5-turbo',
            'messages' => [
                ['role' => 'system', 'content' => 'You are a helpful assistant.'],
                ['role' => 'user', 'content' => $text]
            ],
            'temperature' => 0.0,
            'max_tokens' => 1500,
            'frequency_penalty' => 0,
            'presence_penalty' => 0.6,
        ],
    ]);

    $responseBody = $response->getBody()->getContents();
    $responseObj = json_decode($responseBody);

    if (json_last_error() !== JSON_ERROR_NONE) {
        die("Error decoding JSON response: " . json_last_error_msg());
    }

    $responseText = $responseObj->choices[0]->message->content;
    echo "Response from ChatGPT:\n$responseText\n";

    // Extract CVEs from the response text
    preg_match_all('/CVE-\d{4}-\d{4,7}/', $responseText, $matches);
    $cveList = $matches[0];

    if (empty($cveList)) {
        die("No CVEs found in the response.");
    }

    // Function to search for CVE details on the NVD website
    function search_nvd($cve_id) {
        $url = "https://nvd.nist.gov/vuln/detail/$cve_id";
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CAINFO, __DIR__ . '/cacert.pem'); // Set the path to the CA certificate bundle
        $response = curl_exec($ch);
        curl_close($ch);
        return $response;
    }

    // Function to extract patch URLs from the NVD page
    function extract_patch_urls($html_content) {
        $patch_urls = [];
        $dom = new DOMDocument();
        @$dom->loadHTML($html_content); // Use @ to suppress warnings from malformed HTML
        $xpath = new DOMXPath($dom);
        $nodes = $xpath->query('//table[@data-testid="vuln-hyperlinks-table"]//a[@href]');
        
        foreach ($nodes as $node) {
            $patch_urls[] = $node->getAttribute('href');
        }
        return $patch_urls;
    }

    // Function to download the patch from the URL
    function download_patch($url, $download_dir = 'patches') {
        if (!is_dir($download_dir)) {
            mkdir($download_dir, 0777, true);
        }
        $file_name = basename(parse_url($url, PHP_URL_PATH));
        $local_file = "$download_dir/$file_name";
        
        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CAINFO, __DIR__ . '/cacert.pem'); // Set the path to the CA certificate bundle
        $data = curl_exec($ch);
        curl_close($ch);

        if ($data) {
            file_put_contents($local_file, $data);
            echo "Downloaded patch: $local_file\n";
        } else {
            echo "Failed to download patch from: $url\n";
        }
    }

    // Search for patches for each CVE and download them
    foreach ($cveList as $cve_id) {
        echo "Searching for patches for $cve_id...\n";
        $html_content = search_nvd($cve_id);
        if ($html_content) {
            $patch_urls = extract_patch_urls($html_content);
            foreach ($patch_urls as $patch_url) {
                download_patch($patch_url, $downloadDir);
            }
        } else {
            echo "No information found for $cve_id.\n";
        }
    }

    echo "Patch download completed.\n";

} catch (RequestException $e) {
    if ($e->hasResponse()) {
        $errorResponse = $e->getResponse();
        $statusCode = $errorResponse->getStatusCode();
        $errorBody = $errorResponse->getBody()->getContents();
        die("HTTP Status Code: $statusCode\nError Response: $errorBody");
    } else {
        die("Request failed: " . $e->getMessage());
    }
}
